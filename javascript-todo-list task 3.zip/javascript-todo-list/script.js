const STORAGE_KEY = "taskflow-todos-v1";

let state = {
  tasks: loadTasks(),
  filter: "all"
};

const elements = {
  form: document.querySelector("#taskForm"),
  input: document.querySelector("#taskInput"),
  list: document.querySelector("#taskList"),
  filters: document.querySelector(".filters"),
  clearCompleted: document.querySelector("#clearCompleted"),
  remaining: document.querySelector("#remainingCount"),
  total: document.querySelector("#totalCount"),
  empty: document.querySelector("#emptyState"),
  emptyTitle: document.querySelector("#emptyTitle"),
  emptyMessage: document.querySelector("#emptyMessage")
};

function loadTasks() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch (error) {
    console.error("Unable to load tasks:", error);
    return [];
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.tasks));
}

function createTask(title) {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
    title: title.trim(),
    completed: false,
    createdAt: Date.now()
  };
}

function addTask(title) {
  const cleanTitle = title.trim();
  if (!cleanTitle) return;

  state.tasks.unshift(createTask(cleanTitle));
  saveTasks();
  render();
}

function updateTask(id, changes) {
  state.tasks = state.tasks.map(task =>
    task.id === id ? { ...task, ...changes } : task
  );
  saveTasks();
  render();
}

function deleteTask(id) {
  state.tasks = state.tasks.filter(task => task.id !== id);
  saveTasks();
  render();
}

function getVisibleTasks() {
  if (state.filter === "active") {
    return state.tasks.filter(task => !task.completed);
  }
  if (state.filter === "completed") {
    return state.tasks.filter(task => task.completed);
  }
  return state.tasks;
}

function render() {
  const visibleTasks = getVisibleTasks();
  elements.list.innerHTML = visibleTasks.map(task => `
    <li class="task-item ${task.completed ? "completed" : ""}" data-id="${task.id}">
      <input class="task-checkbox" type="checkbox"
             ${task.completed ? "checked" : ""}
             aria-label="Mark ${escapeHTML(task.title)} as ${task.completed ? "active" : "completed"}">
      <span class="task-text">${escapeHTML(task.title)}</span>
      <div class="actions">
        <button class="icon-button edit" type="button" data-action="edit">Edit</button>
        <button class="icon-button delete" type="button" data-action="delete">Delete</button>
      </div>
    </li>
  `).join("");

  const remaining = state.tasks.filter(task => !task.completed).length;
  const completed = state.tasks.filter(task => task.completed).length;

  elements.remaining.textContent = remaining;
  elements.total.textContent = `${state.tasks.length} ${state.tasks.length === 1 ? "task" : "tasks"}`;

  document.querySelectorAll(".filter").forEach(button => {
    button.classList.toggle("active", button.dataset.filter === state.filter);
  });

  const isEmpty = visibleTasks.length === 0;
  elements.empty.hidden = !isEmpty;

  if (isEmpty) {
    if (state.tasks.length === 0) {
      elements.emptyTitle.textContent = "No tasks yet";
      elements.emptyMessage.textContent = "Add your first task to get started.";
    } else if (state.filter === "active") {
      elements.emptyTitle.textContent = "All caught up!";
      elements.emptyMessage.textContent = "You have no active tasks.";
    } else if (state.filter === "completed") {
      elements.emptyTitle.textContent = "Nothing completed";
      elements.emptyMessage.textContent = "Completed tasks will appear here.";
    } else {
      elements.emptyTitle.textContent = "No tasks found";
      elements.emptyMessage.textContent = "Try adding a new task.";
    }
  }
}

function editTask(item, id) {
  const task = state.tasks.find(task => task.id === id);
  if (!task) return;

  const text = item.querySelector(".task-text");
  const input = document.createElement("input");
  input.className = "edit-input";
  input.value = task.title;
  input.maxLength = 120;
  input.setAttribute("aria-label", "Edit task");

  text.replaceWith(input);
  input.focus();
  input.select();

  const finishEdit = () => {
    const newTitle = input.value.trim();
    if (newTitle) updateTask(id, { title: newTitle });
    else render();
  };

  input.addEventListener("keydown", event => {
    if (event.key === "Enter") finishEdit();
    if (event.key === "Escape") render();
  });
  input.addEventListener("blur", finishEdit, { once: true });
}

function escapeHTML(value) {
  const div = document.createElement("div");
  div.textContent = value;
  return div.innerHTML;
}

// Create
elements.form.addEventListener("submit", event => {
  event.preventDefault();
  addTask(elements.input.value);
  elements.input.value = "";
  elements.input.focus();
});

// Read + Update + Delete through event delegation
elements.list.addEventListener("click", event => {
  const item = event.target.closest(".task-item");
  if (!item) return;

  const id = item.dataset.id;
  const action = event.target.closest("[data-action]")?.dataset.action;

  if (action === "delete") deleteTask(id);
  if (action === "edit") editTask(item, id);
});

elements.list.addEventListener("change", event => {
  if (!event.target.classList.contains("task-checkbox")) return;

  const item = event.target.closest(".task-item");
  updateTask(item.dataset.id, { completed: event.target.checked });
});

// Filter
elements.filters.addEventListener("click", event => {
  const button = event.target.closest(".filter");
  if (!button) return;

  state.filter = button.dataset.filter;
  render();
});

// Delete all completed tasks
elements.clearCompleted.addEventListener("click", () => {
  state.tasks = state.tasks.filter(task => !task.completed);
  saveTasks();
  render();
});

render();
