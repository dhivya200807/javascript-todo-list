# TaskFlow — JavaScript To-Do List

A responsive, client-side To-Do List application built with **HTML, CSS and vanilla JavaScript**.

## Features

- Create tasks
- Read and display tasks dynamically
- Update/edit existing tasks
- Delete individual tasks
- Mark tasks as completed
- Filter by **All, Active, Completed**
- Clear all completed tasks
- Automatic persistence with `window.localStorage`
- Event delegation for dynamic task controls
- Responsive layout for desktop and mobile
- Accessible form labels and live regions

## CRUD Implementation

| Operation | Implementation |
|---|---|
| Create | Add a new task through the form |
| Read | Render tasks from application state |
| Update | Edit task text or completion status |
| Delete | Delete one task or clear completed tasks |

## Technologies

- HTML5
- CSS3
- JavaScript (ES6+)
- DOM Manipulation
- Event Handling
- Local Storage API

## How to Run

1. Download or clone this repository.
2. Open `index.html` in a browser.
3. Add tasks and test the filters, edit, delete and completion features.
4. Refresh the page to verify that tasks are still saved.

No backend or installation is required.

## Learning Outcomes

This project demonstrates state-driven UI rendering, DOM manipulation, event delegation, CRUD logic and browser-side data persistence using `localStorage`.

## Author

Dhivya
